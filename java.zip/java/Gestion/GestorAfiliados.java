package Gestion;

import Modelo.Afiliado;
import java.util.ArrayList;

public class GestorAfiliados {

    private ArrayList<Afiliado> afiliados;

    public GestorAfiliados() {
        afiliados = new ArrayList<>();
    }

    public boolean registrarAfiliado(Afiliado afiliado) {

        if (buscarPorDocumento(afiliado.getDocumento()) != null) {
            return false;
        }

        afiliados.add(afiliado);
        return true;
    }

    public Afiliado buscarPorDocumento(String documento) {

        for (Afiliado afiliado : afiliados) {

            if (afiliado.getDocumento().equals(documento)) {
                return afiliado;
            }
        }

        return null;
    }

    public ArrayList<Afiliado> getAfiliados() {
        return afiliados;
    }
}