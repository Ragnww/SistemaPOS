package Gestion;

import Modelo.Usuario;
import java.util.ArrayList;

public class GestorUsuarios {

    private ArrayList<Usuario> usuarios;

    public GestorUsuarios() {
        usuarios = new ArrayList<>();
    }

    public boolean registrarUsuario(Usuario usuario) {

        if (buscarPorNombreUsuario(usuario.getNombreUsuario()) != null) {
            return false;
        }

        usuarios.add(usuario);
        return true;
    }

    public Usuario buscarPorNombreUsuario(String nombreUsuario) {

        for (Usuario usuario : usuarios) {

            if (usuario.getNombreUsuario().equalsIgnoreCase(nombreUsuario)) {
                return usuario;
            }
        }

        return null;
    }

    public Usuario iniciarSesion(String nombreUsuario, String contrasena) {

        Usuario usuario = buscarPorNombreUsuario(nombreUsuario);

        if (usuario != null && usuario.getContrasena().equals(contrasena)) {
            return usuario;
        }

        return null;
    }
}