package Gestion;

import Modelo.Producto;
import java.util.ArrayList;

public class Inventario {

    private ArrayList<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public void registrarProducto(Producto producto) {

        if (buscarProducto(producto.getCodigo()) != null) {
            System.out.println("Ya existe un producto con ese codigo.");
            return;
        }

        productos.add(producto);
        System.out.println("Producto registrado correctamente.");
    }
    public void registrarProductoSilencioso(Producto producto) {
        if (buscarProducto(producto.getCodigo()) == null) {
            productos.add(producto);
        }
    }

    public Producto buscarProducto(String codigo) {

        for (Producto producto : productos) {

            if (producto.getCodigo().equalsIgnoreCase(codigo)) {
                return producto;
            }
        }

        return null;
    }

    public ArrayList<Producto> buscarPorNombre(String nombre) {

        ArrayList<Producto> encontrados = new ArrayList<>();

        for (Producto producto : productos) {

            if (producto.getNombre().toLowerCase()
                    .contains(nombre.toLowerCase())) {

                encontrados.add(producto);
            }
        }

        return encontrados;
    }

    public boolean modificarProducto(String codigo, String nuevoNombre,
            double nuevoPrecio, int nuevoStock, String nuevaCategoria) {

        Producto producto = buscarProducto(codigo);

        if (producto == null) {
            return false;
        }

        if (nuevoPrecio < 0 || nuevoStock < 0) {
            return false;
        }

        producto.setNombre(nuevoNombre);
        producto.setPrecio(nuevoPrecio);
        producto.setStock(nuevoStock);
        producto.setCategoria(nuevaCategoria);

        return true;
    }

    public boolean eliminarProducto(String codigo) {

        Producto producto = buscarProducto(codigo);

        if (producto == null) {
            return false;
        }

        productos.remove(producto);
        return true;
    }

    public void mostrarProductos() {

        if (productos.isEmpty()) {
            System.out.println("El inventario esta vacio.");
            return;
        }

        for (Producto producto : productos) {
            producto.mostrarInformacion();
            System.out.println("----------------------");
        }
    }
}