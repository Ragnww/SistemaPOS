package Gestion;

import Modelo.*;
import java.util.ArrayList;

public class GestorVentas {

    private Inventario inventario;
    private ArrayList<Venta> ventas;
    private int contadorVentas;

    public GestorVentas(Inventario inventario) {
        this.inventario = inventario;
        this.ventas = new ArrayList<>();
        this.contadorVentas = 1;
    }

    public Venta crearVenta(Cajero cajero, Afiliado afiliado) {
        return new Venta(contadorVentas++, cajero, afiliado);
    }

    public boolean agregarProducto(Venta venta, String codigo, int cantidad) {

        Producto producto = inventario.buscarProducto(codigo);

        if (producto == null || cantidad <= 0) {
            return false;
        }

        int cantidadEnCarrito = 0;

        for (DetalleVenta detalle : venta.getDetalles()) {
            if (detalle.getProducto().getCodigo().equalsIgnoreCase(codigo)) {
                cantidadEnCarrito += detalle.getCantidad();
            }
        }

        if (producto.getStock() < cantidadEnCarrito + cantidad) {
            return false;
        }

        DetalleVenta detalle = new DetalleVenta(producto, cantidad);
        venta.agregarDetalle(detalle);

        return true;
    }

    public boolean finalizarVenta(Venta venta) {

        if (venta.getDetalles().isEmpty()) {
            System.out.println("No se puede finalizar una venta vacia.");
            return false;
        }

        for (DetalleVenta detalle : venta.getDetalles()) {

            Producto producto = detalle.getProducto();

            if (producto.getStock() < detalle.getCantidad()) {
                System.out.println("Stock insuficiente para: " + producto.getNombre());
                return false;
            }
        }

        for (DetalleVenta detalle : venta.getDetalles()) {

            Producto producto = detalle.getProducto();

            producto.setStock(
                producto.getStock() - detalle.getCantidad()
            );
        }

        ventas.add(venta);

        System.out.println("Venta finalizada correctamente.");
        System.out.println("Subtotal: $" + venta.calcularSubtotal());
        System.out.println("Descuento: $" + venta.calcularDescuento());
        System.out.println("Total: $" + venta.calcularTotal());

        return true;
    }

    public ArrayList<Venta> getVentas() {
        return ventas;
    }
}