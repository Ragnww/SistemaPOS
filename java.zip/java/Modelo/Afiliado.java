package Modelo;

public class Afiliado {

    private String documento;
    private String nombre;
    private String telefono;
    private String correo;

    public Afiliado(String documento, String nombre,
                    String telefono, String correo) {
        this.documento = documento;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
    }

    public String getDocumento() {
        return documento;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public double obtenerDescuento() {
        return 0.05;
    }
}