package Modelo;

public class Administrador extends Cajero {

    public Administrador(int id, String nombre,
                         String nombreUsuario, String contrasena) {
        super(id, nombre, nombreUsuario, contrasena);
    }

    @Override
    public String getRol() {
        return "Administrador";
    }
}