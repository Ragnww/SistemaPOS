package Modelo;

public class Cajero extends Usuario {

    public Cajero(int id, String nombre, String nombreUsuario, String contrasena) {
        super(id, nombre, nombreUsuario, contrasena);
    }

    @Override
    public String getRol() {
        return "Cajero";
    }

}