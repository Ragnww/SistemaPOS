package Modelo;

import java.util.ArrayList;
import java.time.LocalDateTime;

public class Venta {

    private int numero;
    private LocalDateTime fecha;
    private Cajero cajero;
    private Afiliado afiliado;
    private ArrayList<DetalleVenta> detalles;

    public Venta(int numero, Cajero cajero, Afiliado afiliado) {
        this.numero = numero;
        this.fecha = LocalDateTime.now();
        this.cajero = cajero;
        this.afiliado = afiliado;
        this.detalles = new ArrayList<>();
    }

    public int getNumero() {
        return numero;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public Cajero getCajero() {
        return cajero;
    }

    public Afiliado getAfiliado() {
        return afiliado;
    }

    public ArrayList<DetalleVenta> getDetalles() {
        return detalles;
    }

    public void agregarDetalle(DetalleVenta detalle) {
        detalles.add(detalle);
    }

    public double calcularSubtotal() {
        double subtotal = 0;

        for (DetalleVenta detalle : detalles) {
            subtotal += detalle.calcularSubtotal();
        }

        return subtotal;
    }

    public double calcularDescuento() {
        if (afiliado == null) {
            return 0;
        }

        return calcularSubtotal() * afiliado.obtenerDescuento();
    }

    public double calcularTotal() {
        return calcularSubtotal() - calcularDescuento();
    }
}