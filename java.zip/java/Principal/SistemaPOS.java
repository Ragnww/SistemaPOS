package Principal;

import Modelo.*;
import Gestion.*;
import java.util.Scanner;
import java.util.ArrayList;

public class SistemaPOS {

    private static Scanner scanner = new Scanner(System.in);
    private static GestorUsuarios gestorUsuarios = new GestorUsuarios();
    private static Inventario inventario = new Inventario();
    private static GestorAfiliados gestorAfiliados = new GestorAfiliados();
    private static GestorVentas gestorVentas = new GestorVentas(inventario);

    public static void main(String[] args) {

        cargarDatosdePrueba();

        while (true) {

            System.out.println("\n========== SISTEMA POS ==========");
            System.out.println("1. Iniciar sesion");
            System.out.println("2. Cerrar programa");
            System.out.println("=================================");
            System.out.print("Seleccione una opcion: ");

            String opcion = scanner.nextLine();

            if (opcion.equals("2")) {
                System.out.println("Cerrando programa...");
                scanner.close();
                System.exit(0);
            }

            if (!opcion.equals("1")) {
                System.out.println("Opcion no valida.");
                continue;
            }

            Usuario usuario = iniciarSesion();

            if (usuario == null) {
                System.out.println("Demasiados intentos fallidos.");
                System.out.println("____________________________");
                continue;
            }

            mostrarBienvenida(usuario);

            if (usuario instanceof Administrador) {
                menuAdministrador((Administrador) usuario);
            } else {
                menuCajero((Cajero) usuario);
            }

            System.out.println("Sesion cerrada.");
            System.out.println("____________________________");
        }
    }
    public static Usuario iniciarSesion() {
        Usuario usuario = null;
        int intentos = 3;

        while (intentos > 0 && usuario == null) {
            System.out.print("Usuario: ");
            String nombreUsuario = scanner.nextLine();

            System.out.print("Contraseña: ");
            String contrasena = scanner.nextLine();

            usuario = gestorUsuarios.iniciarSesion(nombreUsuario, contrasena);

            if (usuario == null) {
                intentos--;
                System.out.println("Datos incorrectos.");
                System.out.println("Intentos restantes: " + intentos);
                System.out.println("____________________________");
            }
        }

        return usuario;
    }
    
    public static void cargarDatosdePrueba() {

        Administrador admin = new Administrador(
                1, "Carlos Ramirez", "admin", "1234"
        );

        Cajero cajero = new Cajero(
                2, "Laura Martinez", "cajero", "1234"
        );

        gestorUsuarios.registrarUsuario(admin);
        gestorUsuarios.registrarUsuario(cajero);

        inventario.registrarProductoSilencioso(
                new Producto("P001", "Arroz 1kg", 4500, 30, "Granos")
        );

        inventario.registrarProductoSilencioso(
                new Producto("P002", "Frijoles 500g", 6000, 20, "Granos")
        );

        inventario.registrarProductoSilencioso(
                new Producto("P003", "Aceite 1L", 8500, 15, "Aceites")
        );

        inventario.registrarProductoSilencioso(
                new Producto("P004", "Leche 1L", 4200, 25, "Lacteos")
        );

        inventario.registrarProductoSilencioso(
                new Producto("P005", "Huevos x 12", 9000, 18, "Lacteos")
        );

        inventario.registrarProductoSilencioso(
                new Producto("P006", "Pan tajado", 6500, 12, "Panaderia")
        );

        inventario.registrarProductoSilencioso(
                new Producto("P007", "Azucar 1kg", 4800, 20, "Granos")
        );

        inventario.registrarProductoSilencioso(
                new Producto("P008", "Cafe 250g", 11000, 10, "Bebidas")
        );

        Afiliado afiliado = new Afiliado(
                "1020304050",
                "Andres Gomez",
                "3104567890",
                "andres@gmail.com"
        );

        gestorAfiliados.registrarAfiliado(afiliado);
    }

    public static void mostrarBienvenida(Usuario usuario) {

        System.out.println("Bienvenido, " + usuario.getNombre());
        System.out.println("Rol: " + usuario.getRol());
        System.out.println("____________________________");
    }
    
    public static void menuCajero(Cajero cajero) {

        String opcion = "";

        while (!opcion.equals("5")) {

            System.out.println("\n========== MENU CAJERO ==========");
            System.out.println("1. Buscar producto por codigo");
            System.out.println("2. Buscar producto por nombre");
            System.out.println("3. Consultar inventario");
            System.out.println("4. Realizar una venta");
            System.out.println("5. Cerrar sesion");
            System.out.println("=================================");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    buscarProductoPorCodigo();
                    break;

                case "2":
                    buscarProductoPorNombre();
                    break;

                case "3":
                    inventario.mostrarProductos();
                    System.out.println("____________________________");
                    break;

                case "4":
                    realizarVenta(cajero);
                    break;

                case "5":
                    System.out.println("Cerrando sesion...");
                    System.out.println("____________________________");
                    break;

                default:
                    System.out.println("Opcion no valida.");
                    System.out.println("____________________________");
            }
        }
    }
    
    public static void buscarProductoPorCodigo() {

        System.out.print("Ingrese el codigo del producto: ");
        String codigo = scanner.nextLine();

        Producto producto = inventario.buscarProducto(codigo);

        if (producto != null) {
            producto.mostrarInformacion();
        } else {
            System.out.println("Producto no encontrado.");
        }

        System.out.println("____________________________");
    }

    public static void buscarProductoPorNombre() {

        System.out.print("Ingrese el nombre del producto: ");
        String nombre = scanner.nextLine();

        ArrayList<Producto> encontrados =
            inventario.buscarPorNombre(nombre);

        if (encontrados.isEmpty()) {
            System.out.println("No se encontraron productos.");
        } else {
            for (Producto producto : encontrados) {
                producto.mostrarInformacion();
                System.out.println("----------------------------");
            }
        }

        System.out.println("____________________________");
    }
    
    public static void realizarVenta(Cajero cajero) {

        System.out.println("\n========== NUEVA VENTA ==========");

        Afiliado afiliado = null;

        System.out.print("¿El comprador es afiliado? (S/N): ");
        String respuesta = scanner.nextLine();

        if (respuesta.equalsIgnoreCase("S")) {

            System.out.print("Ingrese el documento del afiliado: ");
            String documento = scanner.nextLine();

            afiliado = gestorAfiliados.buscarPorDocumento(documento);

            if (afiliado == null) {
                System.out.println("Afiliado no encontrado.");
                System.out.println("Se continuara sin descuento.");
            } else {
                System.out.println("Afiliado encontrado: "
                        + afiliado.getNombre());
            }
        }

        Venta venta = gestorVentas.crearVenta(cajero, afiliado);

        String continuar = "S";

        while (continuar.equalsIgnoreCase("S")) {

            System.out.println("\n--- Agregar producto ---");

            System.out.print("Codigo del producto: ");
            String codigo = scanner.nextLine();

            int cantidad = leerEntero("Cantidad: ", 1);

            boolean agregado = gestorVentas.agregarProducto(
                    venta, codigo, cantidad
            );

            if (agregado) {
                System.out.println("Producto agregado correctamente.");
            } else {
                System.out.println("No se pudo agregar el producto.");
                System.out.println("Verifique el codigo, la cantidad y el stock.");
            }

            System.out.println("____________________________");

            System.out.print("¿Desea agregar otro producto? (S/N): ");
            continuar = scanner.nextLine();
        }

        if (venta.getDetalles().isEmpty()) {
            System.out.println("La venta no contiene productos.");
            System.out.println("____________________________");
            return;
        }

        System.out.println("\n========== RESUMEN DE VENTA ==========");
        System.out.println("Subtotal: $" + venta.calcularSubtotal());
        System.out.println("Descuento: $" + venta.calcularDescuento());
        System.out.println("Total: $" + venta.calcularTotal());
        System.out.println("____________________________");

        System.out.print("¿Desea confirmar la venta? (S/N): ");
        String confirmar = scanner.nextLine();

        if (confirmar.equalsIgnoreCase("S")) {
            gestorVentas.finalizarVenta(venta);
        } else {
            System.out.println("Venta cancelada.");
            System.out.println("No se modifico el inventario.");
        }

        System.out.println("____________________________");
    }
    
    public static void menuAdministrador(Administrador admin) {

        String opcion = "";

        while (!opcion.equals("10")) {

            System.out.println("\n======= MENU ADMINISTRADOR =======");
            System.out.println("1. Buscar producto por codigo");
            System.out.println("2. Buscar producto por nombre");
            System.out.println("3. Consultar inventario");
            System.out.println("4. Realizar una venta");
            System.out.println("5. Registrar producto");
            System.out.println("6. Modificar producto");
            System.out.println("7. Eliminar producto");
            System.out.println("8. Registrar usuario");
            System.out.println("9. Registrar afiliado");
            System.out.println("10. Cerrar sesion");
            System.out.println("==================================");

            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextLine();

            switch (opcion) {

                case "1":
                    buscarProductoPorCodigo();
                    break;

                case "2":
                    buscarProductoPorNombre();
                    break;

                case "3":
                    inventario.mostrarProductos();
                    System.out.println("____________________________");
                    break;

                case "4":
                    realizarVenta(admin);
                    break;

                case "5":
                    registrarProducto();
                    break;

                case "6":
                    modificarProducto();
                    break;

                case "7":
                    eliminarProducto();
                    break;

                case "8":
                    registrarUsuario();
                    break;

                case "9":
                    registrarAfiliado();
                    break;

                case "10":
                    System.out.println("Cerrando sesion...");
                    System.out.println("____________________________");
                    break;

                default:
                    System.out.println("Opcion no valida.");
                    System.out.println("____________________________");
            }
        }
    }
     
    public static void registrarProducto() {

        System.out.println("\n===== REGISTRAR PRODUCTO =====");

        System.out.print("Codigo: ");
        String codigo = scanner.nextLine();

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        double precio = leerDecimal("Precio: ");

        int stock = leerEntero("Stock: ", 0);

        System.out.print("Categoria: ");
        String categoria = scanner.nextLine();

        Producto producto = new Producto(
            codigo, nombre, precio, stock, categoria
        );

        inventario.registrarProducto(producto);

        System.out.println("____________________________");
    }

    public static void modificarProducto() {

        System.out.println("\n===== MODIFICAR PRODUCTO =====");

        System.out.print("Codigo del producto: ");
        String codigo = scanner.nextLine();

        Producto producto = inventario.buscarProducto(codigo);

        if (producto == null) {
            System.out.println("Producto no encontrado.");
            System.out.println("____________________________");
            return;
        }

        producto.mostrarInformacion();

        System.out.print("Nuevo nombre: ");
        String nombre = scanner.nextLine();

        double precio = leerDecimal("Nuevo precio: ");

        int stock = leerEntero("Nuevo stock: ", 0);

        System.out.print("Nueva categoria: ");
        String categoria = scanner.nextLine();

        boolean modificado = inventario.modificarProducto(
            codigo, nombre, precio, stock, categoria
        );

        if (modificado) {
            System.out.println("Producto modificado correctamente.");
        } else {
            System.out.println("No se pudo modificar el producto.");
        }

        System.out.println("____________________________");
    }
    
    public static void eliminarProducto() {

        System.out.println("\n===== ELIMINAR PRODUCTO =====");

        System.out.print("Codigo del producto: ");
        String codigo = scanner.nextLine();

        boolean eliminado = inventario.eliminarProducto(codigo);

        if (eliminado) {
            System.out.println("Producto eliminado correctamente.");
        } else {
            System.out.println("Producto no encontrado.");
        }

        System.out.println("____________________________");
    }
    
    public static void registrarUsuario() {

        System.out.println("\n===== REGISTRAR USUARIO =====");

        System.out.println("1. Cajero");
        System.out.println("2. Administrador");
        System.out.print("Seleccione el rol: ");

        String rol = scanner.nextLine();

        if (!rol.equals("1") && !rol.equals("2")) {
            System.out.println("Rol no valido.");
            System.out.println("____________________________");
            return;
        }

        int id = leerEntero("ID: ", 1);

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Nombre de usuario: ");
        String nombreUsuario = scanner.nextLine();

        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        Usuario nuevoUsuario;

        if (rol.equals("1")) {
            nuevoUsuario = new Cajero(
                id, nombre, nombreUsuario, contrasena
            );
        } else {
            nuevoUsuario = new Administrador(
                id, nombre, nombreUsuario, contrasena
            );
        }

        if (gestorUsuarios.registrarUsuario(nuevoUsuario)) {
            System.out.println("Usuario registrado correctamente.");
        } else {
            System.out.println("Ese nombre de usuario ya existe.");
        }

        System.out.println("____________________________");
    }
    
    public static void registrarAfiliado() {

        System.out.println("\n===== REGISTRAR AFILIADO =====");

        System.out.print("Documento: ");
        String documento = scanner.nextLine();

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Telefono: ");
        String telefono = scanner.nextLine();

        System.out.print("Correo: ");
        String correo = scanner.nextLine();

        Afiliado afiliado = new Afiliado(
            documento, nombre, telefono, correo
        );

        if (gestorAfiliados.registrarAfiliado(afiliado)) {
            System.out.println("Afiliado registrado correctamente.");
        } else {
            System.out.println("Ya existe un afiliado con ese documento.");
        }

        System.out.println("____________________________");
    }
    
    public static int leerEntero(String mensaje, int minimo) {

        while (true) {

            System.out.print(mensaje);

            try {
                int numero = Integer.parseInt(scanner.nextLine());

                if (numero < minimo) {
                    System.out.println("El numero debe ser mayor o igual a " + minimo);
                    continue;
                }

                return numero;

            } catch (NumberFormatException e) {
                System.out.println("Error: debe ingresar un numero entero.");
            }
        }
    }

    public static double leerDecimal(String mensaje) {

        while (true) {

            System.out.print(mensaje);

            try {
                double numero = Double.parseDouble(scanner.nextLine());

                if (!Double.isFinite(numero) || numero < 0) {
                    System.out.println("Ingrese un precio valido y no negativo.");
                    continue;
                }

                return numero;

            } catch (NumberFormatException e) {
                System.out.println("Error: debe ingresar un numero valido.");
            }
        }
    }
}